"use client"
import React, { useEffect, useState } from 'react';
import { useKindeBrowserClient } from "@kinde-oss/kinde-auth-nextjs";
import Image from 'next/image';
import { CalendarDays, Clock3, Users } from 'lucide-react';
import Wrapper from '../components/Wrapper';

// Définir une interface pour les réservations
interface Room {
  id: string;
  name: string;
  capacity: number;
  description?: string;
  imageUrl?: string;
}

interface Reservation {
  id: string;
  room: Room;
  reservationDate: string;
  startTime: string;
  endTime: string;
}

const ReservationsPage: React.FC = () => {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const { user } = useKindeBrowserClient(); // Utilisation du hook pour obtenir l'utilisateur
  const [loading, setLoading] = React.useState<boolean>(true);

  // Fonction pour récupérer les réservations
  const fetchReservations = async () => {
    if (!user?.email) return; // Vérifier si l'email de l'utilisateur est disponible

    try {
      const response = await fetch(`/api/reservations?email=${user?.email}`);
      const data: Reservation[] = await response.json();
      setReservations(data); // Met à jour l'état avec les réservations récupérées
      setLoading(false);
    } catch (error) {
      console.error('Error fetching reservations:', error);
    }
  };

  // Fonction pour supprimer une réservation
  const deleteReservation = async (id: string) => {
    try {
      const response = await fetch('/api/reservations', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id }), // Envoie l'ID de la réservation à supprimer
      });

      if (response.ok) {
        // Filtre la réservation supprimée de la liste
        setReservations((prev) => prev.filter((reservation) => reservation.id !== id));
      } else {
        console.error('Failed to delete reservation');
      }
    } catch (error) {
      console.error('Error deleting reservation:', error);
    }
  };

  useEffect(() => {
    fetchReservations(); // Appelle la fonction pour récupérer les réservations au chargement de la page
  }, [user]); // Dépendance à `user` pour se mettre à jour lorsque l'utilisateur change

  return (
    <Wrapper>

      {loading ? (
        <div className="text-center ">
          <span className="loading loading-spinner loading-lg"></span>
        </div>
      ) : (
        <div>

          <h1 className="text-2xl mb-4">Tes réservations</h1>
          {reservations.length === 0 ? (
            <p>Aucune réservation trouvée.</p>
          ) : (
            <ul className='grid md:grid-cols-2 gap-4'>
              {reservations.map((reservation) => (
                <li key={reservation.id} className='flex items-center mb-5 border-base-300 border p-5 rounded-3xl w-full h-60'>

                  <Image src={`${reservation.room.imageUrl}`}
                    alt={`${reservation.id}`}
                    width={400}  // Augmentez les dimensions pour une meilleure résolution
                    height={400}  // Cela devrait correspondre à un aspect similaire mais plus haute qualité
                    quality={90}  // Ajustez la qualité pour un bon compromis entre qualité et performance
                    className='shadow-sm w-1/3 h-full object-cover rounded-xl'>
                  </Image>

                  <div className='ml-6'>

                    <div className="flex flex-col md:flex-row md:items-center  ">
                      <div className="badge badge-secondary">
                        <Users className="mr-2 w-4" /> {reservation.room.capacity}
                      </div>
                      <h1 className="font-bold text-md md:text-xl md:ml-2">{reservation.room.name}</h1>
                    </div>
                    <div className='my-2'>
                      <p className='flex '><CalendarDays className='w-6 text-secondary' /> <span className='ml-1'>{reservation.reservationDate}</span></p>
                      <p className='flex mt-1'><Clock3 className='w-6 text-secondary' /> <span className='ml-1'>{reservation.startTime} - {reservation.endTime}</span></p>
                    </div>
                    <button className='btn btn-outline btn-sm mt-1   btn-secondary' onClick={() => deleteReservation(reservation.id)}>Libérer</button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </Wrapper>
  );
};

export default ReservationsPage;
