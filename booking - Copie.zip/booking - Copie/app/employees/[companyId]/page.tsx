"use client";

import { useEffect, useState } from 'react';
import { useKindeBrowserClient } from '@kinde-oss/kinde-auth-nextjs';
import Wrapper from '@/app/components/Wrapper';
import Notification from '@/app/components/Notification';

function Page({ params }: { params: { companyId: string } }) {
    const { user } = useKindeBrowserClient();
    const [employeeEmail, setEmployeeEmail] = useState('');
    const [companyName, setCompanyName] = useState('');
    const [employees, setEmployees] = useState<Employee[]>([]); // État pour les employés
    const [loading, setLoading] = useState(true); // Ajout de l'état de chargement


    const [notification, setNotification] = useState<string>(''); // État de la notification
    // Fonction pour fermer la notification
    const closeNotification = () => {
        setNotification('');
    };



    // Afficher les employés
    const fetchEmployees = async () => {
        try {
            const response = await fetch(`/api/employees?companyId=${params.companyId}`);
            if (!response.ok) {
                const data = await response.json();
                throw new Error(data.message);
            }
            const data = await response.json();
            setEmployees(data.employees);
            setCompanyName(data.companyName);
            setLoading(false);
        } catch (error) {
            console.error(error);
        }
    };

    useEffect(() => {
        fetchEmployees();
    }, [params.companyId]);

    // Ajouter des employés
    const handleAddEmployee = async (e: React.FormEvent) => {
        e.preventDefault();

        const response = await fetch('/api/companies', {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: params.companyId,
                creatorEmail: user?.email, // Utilisez l'email de l'utilisateur connecté
                employeeEmail: employeeEmail,
                action: 'ADD', // Spécifie l'action d'ajout
            }),
        });

        const data = await response.json();
        if (response.ok) {
            setNotification('Employé ajouté avec succès !');
            // Recharger la liste des employés après l'ajout
            fetchEmployees();
        } else {
            setNotification(`Erreur : ${data.error}`);
        }

        // Réinitialiser le formulaire après l'ajout
        setEmployeeEmail('');
    };

    // Supprimer un employé
    const handleRemoveEmployee = async (employeeEmail: string) => {
        const response = await fetch('/api/companies', {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: params.companyId,
                creatorEmail: user?.email,
                employeeEmail: employeeEmail,
                action: 'DELETE', // Spécifie l'action de suppression
            }),
        });

        const data = await response.json();
        if (response.ok) {
            setNotification('Employé supprimé avec succès !');
            // Recharger la liste des employés après la suppression
            fetchEmployees();
        } else {
            setNotification(`Erreur : ${data.error}`);
        }
    };

    return (
        <Wrapper>
            {notification && (
                <Notification message={notification} onClose={closeNotification} />
            )}
            <div>
                {loading ? (
                    <div className="text-center ">
                        <span className="loading loading-spinner loading-lg"></span>
                    </div>
                ) : (
                    <>
                        <div className="badge badge-secondary badge-outline mb-2">{companyName}</div>
                        <h1 className="text-2xl mb-4">Ajouter un Nouvel Employé</h1>

                        <form onSubmit={handleAddEmployee}>
                            <div className='mb-4 flex flex-row'>
                                <input
                                    type="email"
                                    value={employeeEmail}
                                    placeholder="Email de l'employé"
                                    onChange={(e) => setEmployeeEmail(e.target.value)}
                                    className="input input-bordered w-full max-w-xs"
                                    required
                                />
                                <button className="btn btn-secondary ml-2" type="submit">Ajouter l'Employé</button>
                            </div>
                        </form>

                        <h1 className="text-2xl font-bold mb-4">Liste des Employés</h1>
                        <div className="mt-4">
                            {employees.length > 0 ? (
                                <ol className="divide-base-200 divide-y">
                                    {employees.map((employee) => {
                                        const hasFullName = employee.givenName && employee.familyName;
                                        return (
                                            <li key={employee.id} className="py-4 flex flex-col md:flex-row items-start md:items-center justify-between">
                                                {/* Email avec indicateur */}
                                                <div className="flex items-center md:mb-0">
                                                    <span
                                                        className={`relative flex h-3 w-3 mr-2 rounded-full ${hasFullName ? "bg-green-500" : "bg-red-500"}`}
                                                    >
                                                        <span
                                                            className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${hasFullName ? "bg-green-400" : "bg-red-400"}`}
                                                        ></span>
                                                        <span className="relative inline-flex rounded-full h-3 w-3"></span>
                                                    </span>
                                                    <div>
                                                        <span className='font-bold'>{employee.email}</span>
                                                        <div className="md:mb-0 italic mt-1 text-gray-400">
                                                            {hasFullName
                                                                ? `${employee.givenName} ${employee.familyName}`
                                                                : "Pas encore inscrit"}
                                                        </div>
                                                        <button
                                                            className="btn btn-outline btn-secondary btn-sm mt-2 md:mt-0 flex md:hidden"
                                                            onClick={() => handleRemoveEmployee(employee.email)}
                                                        >
                                                            Enlever
                                                        </button>
                                                    </div>
                                                </div>

                                                {/* Action */}
                                                <div>
                                                    <button
                                                        className="btn btn-outline btn-secondary btn-sm hidden md:flex"
                                                        onClick={() => handleRemoveEmployee(employee.email)}
                                                    >
                                                        Enlever
                                                    </button>
                                                </div>
                                            </li>
                                        );
                                    })}
                                </ol>
                            ) : (
                                <p>Aucun employé trouvé.</p>
                            )}
                        </div>
                    </>
                )}
            </div>
        </Wrapper>
    );


}

interface Employee {
    id: string;
    email: string;
    givenName: string | null; // Peut être null
    familyName: string | null; // Peut être null
}

export default Page;
