'use client';

import Link from 'next/link';
import { useKindeBrowserClient } from "@kinde-oss/kinde-auth-nextjs";
import { useEffect, useState } from "react";
import { usePathname } from 'next/navigation';
import { CalendarCheck, Menu, X } from 'lucide-react';
import { LogoutLink } from "@kinde-oss/kinde-auth-nextjs/components";
import React from 'react';

const Navbar = () => {
    const { user } = useKindeBrowserClient();
    const pathname = usePathname();
    const [loading, setLoading] = useState<boolean>(true);
    const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    useEffect(() => {
        if (user) {
            setLoading(false);
        } else {
            setLoading(true);
        }
    }, [user]);

    const isActive = (link: string) => pathname === link;

    return (
        <div className='  fixed top-0 w-full bg-white backdrop-blur-sm '>
            <nav className=" md:px-[10%] p-5  border-b border-base-200 w-full bg-white">
                <div className="flex items-center justify-between">
                    <div>
                   
                        <h1 className='text-2xl font-bold flex items-center'>
                            <div className='bg-secondary p-1 mr-1 rounded-md text-white'>
                                <CalendarCheck />
                            </div>
                            <span>Book<span className='text-secondary'>It</span></span>
                        </h1>
                             {/* Loading or User Email */}
                             {loading ? (
                            <div className="flex justify-end mt-2 ">
                                <span className="loading loading-spinner loading-xs"></span>
                            </div>
                        ) : (
                            <div className="flex justify-end mt-2 ">
                                <span className="badge badge-ghost">{user?.email}</span>
                            </div>
                        )}
                    </div>

                    {/* Desktop Menu */}
                    <div className='hidden md:flex items-center space-x-6'>
                        <Link href="/create-company" className={`link link-hover   font-bold ${isActive('/create-company') ? 'text-secondary' : ''}`}>
                            Vos entreprises
                        </Link>

                        <Link href="/dashboard" className={`link link-hover   font-bold ${isActive('/dashboard') ? 'text-secondary' : ''}`}>
                            Réserver
                        </Link>

                        <Link href="/my-reservations" className={`link link-hover   font-bold ${isActive('/my-reservations') ? 'text-secondary' : ''}`}>
                            Mes réservations
                        </Link>


                    </div>
                    <LogoutLink className="btn btn-secondary btn-sm hidden md:flex">Déconnexion</LogoutLink>

                    {/* Mobile Menu Button */}
                    <div className='md:hidden'>
                        <button className='link link-hover btn-ghost mb-2 btn' onClick={toggleMenu}>
                            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                        </button>
                    </div>
                </div>
            </nav>

            {/* Mobile Menu */}
            {isMenuOpen && (
                <div className="md:hidden shadow-lg p-4 rounded-lg space-y-4 flex flex-col mt-3">
                    <Link href="/create-company" className={`link link-hover btn-sm   font-bold    ${isActive('/create-company') ? 'text-secondary' : ''}`}>
                        Vos entreprises
                    </Link>

                    <Link href="/dashboard" className={`link link-hover btn-sm   font-bold  ${isActive('/dashboard') ? 'text-secondary' : ''}`}>
                        Réserver
                    </Link>

                    <Link href="/my-reservations" className={`link link-hover btn-sm     font-bold  ${isActive('/my-reservations') ? 'text-secondary' : ''}`}>
                        Mes réservations
                    </Link>

                    <LogoutLink className="link link-hover btn-sm  btn-secondary btn">Déconnexion</LogoutLink>
                </div>
            )}


        </div>
    );
};

export default Navbar;
