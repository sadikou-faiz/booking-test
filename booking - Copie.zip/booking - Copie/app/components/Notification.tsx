// components/Notification.tsx
import { Info } from 'lucide-react';
import React, { useEffect } from 'react';

interface NotificationProps {
    message: string;
    onClose: () => void;
}

const Notification: React.FC<NotificationProps> = ({ message, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose();
        }, 3000); // Ferme la notification après 3 secondes

        return () => clearTimeout(timer); // Nettoyage du timer
    }, [onClose]);

    return (
        <div className="toast toast-top toast-left">
            <div className="alert  p-2 text-sm shadow-xl border border-secondary">
                <span className='flex items-center'><Info className="w-4 mr-2 font-bold text-secondary"/>{message}</span>
            </div>
        </div>
    );
};

export default Notification;
