import React from "react";
import { EdgeStoreProvider } from "@/lib/edgestore";
import Navbar from "./Navbar";


type WrapperProps = {
  children: React.ReactNode;
};

export default function Wrapper({ children }: WrapperProps) {
  return (
    <EdgeStoreProvider>
      <Navbar />
      <div className="px-5 mt-32 md:px-[10%] md:mt-32 mb-10">{children}</div>
    </EdgeStoreProvider>
  );
}
