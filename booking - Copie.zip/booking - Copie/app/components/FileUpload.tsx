import { ImageDown, MonitorUp } from 'lucide-react';
import React, { useRef } from 'react';

interface FileUploadProps {
  onFileChange: (file: File | null) => void; // Fonction pour gérer le changement de fichier
  accept?: string; // Types de fichiers acceptés, par défaut "image/*"
  buttonLabel?: string; // Label pour le bouton
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileChange, accept = "image/*", buttonLabel = "Uploader une image" }) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    onFileChange(file); // Appel à la fonction de changement de fichier
  };

  const handleClick = () => {
    fileInputRef.current?.click(); // Simule le clic sur l'input de fichier
  };

  return (
    <div className=" l">
      <input
        type="file"
        ref={fileInputRef}
        accept={accept}
        onChange={handleFileChange}
        className="hidden" // Masque l'input par défaut
      />
      <div
     
        onClick={handleClick}
        className="cursor-pointer w-full flex justify-center items-center flex-col-reverse "
      >
        {/* SVG Icon */}
        <  ImageDown  className="mt-5 w-8" /> 
        <span className='ml-2 font-bold'>{buttonLabel}</span> {/* Utilisation de la prop buttonLabel */}
      </div>
    </div>
  );
};

export default FileUpload;
