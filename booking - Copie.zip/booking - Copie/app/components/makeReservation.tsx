
"use client";
import React, { useEffect, useState } from 'react';
import { useKindeBrowserClient } from "@kinde-oss/kinde-auth-nextjs";
import Notification from '@/app/components/Notification';

interface Reservation {
  startTime: string;
  endTime: string;
}

interface RoomData {
  roomName: string;
  existingReservations: Reservation[];
}

interface RoomReservationProps {
  roomId: string;
}

const RoomReservation: React.FC<RoomReservationProps> = ({ roomId }) => {

  const { user } = useKindeBrowserClient(); // Utilisation du hook pour obtenir l'utilisateur
  const today = new Date();
  const formattedToday = `${String(today.getDate()).padStart(2, '0')}/${String(today.getMonth() + 1).padStart(2, '0')}/${today.getFullYear()}`;
  const [roomData, setRoomData] = useState<RoomData | null>(null);
  const [availableTimes, setAvailableTimes] = useState<string[]>([]);
  const [selectedStartTime, setSelectedStartTime] = useState('');
  const [selectedEndTime, setSelectedEndTime] = useState('');
  const [selectedDate, setSelectedDate] = useState(formattedToday);
     
  const [notification, setNotification] = useState<string>(''); // État de la notification
  // Fonction pour fermer la notification
  const closeNotification = () => {
      setNotification('');
  };


  const fetchRoomData = async () => {
    const response = await fetch('/api/disponibilities', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        roomId: roomId,
        reservationDate: selectedDate,
      }),
    });

    if (!response.ok) {
      console.error("Erreur lors de la récupération des données:", response.statusText);
      return;
    }

    const data: RoomData = await response.json();
    setRoomData(data);

    const allTimeSlots: string[] = [];
    for (let hour = 8; hour < 20; hour++) {
      for (let minute = 0; minute < 60; minute += 15) {
        const time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
        allTimeSlots.push(time);
      }
    }

    const unavailableTimes = data.existingReservations.flatMap(reservation => {
      const startTime = reservation.startTime;
      const endTime = reservation.endTime;
      return allTimeSlots.filter(time => time >= startTime && time < endTime);
    });

    const available = allTimeSlots.filter(time => !unavailableTimes.includes(time));

    // Si la date choisie est aujourd'hui, filtrer les horaires disponibles
    if (selectedDate === formattedToday) {
      const now = today.toTimeString().slice(0, 5); // Obtenir l'heure actuelle au format HH:mm
      const filteredAvailable = available.filter(time => time >= now);
      setAvailableTimes(filteredAvailable);
    } else {
      setAvailableTimes(available);
    }
  };

  useEffect(() => {
    if (!selectedDate) return;

    fetchRoomData();
  }, [roomId, selectedDate]);

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const chosenDate = e.target.value;
    const [year, month, day] = chosenDate.split('-');
    const formattedDate = `${day}/${month}/${year}`;

    if (chosenDate >= today.toISOString().split('T')[0]) {
      setSelectedDate(formattedDate);
    } else {
      setNotification("Vous ne pouvez pas sélectionner une date antérieure à aujourd'hui.");
    }
  };

  const handleSubmit = async () => {
    if (!selectedStartTime || !selectedEndTime) {
      setNotification("Veuillez sélectionner une heure de début et de fin.");
      return;
    }

    const response = await fetch('/api/reservations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: user?.email, // Use appropriate email here
        roomId: roomId,
        reservationDate: selectedDate,
        startTime: selectedStartTime,
        endTime: selectedEndTime,
      }),
    });

    if (response.ok) {
      const result = await response.json();
      console.log(result)
      setNotification(`Réservation : ${result.reservationDate} de ${result.startTime} à ${result.endTime}`);
      setSelectedStartTime('');
      setSelectedEndTime('');
      fetchRoomData();
    } else {
      const errorData = await response.json();
      setNotification(`Erreur lors de la réservation : ${errorData.message || "Une erreur est survenue."}`);
    }
  };

  return (
    <div className=''>

      {notification && (
        <Notification message={notification} onClose={closeNotification} />
      )}


      <form className='flex flex-col'>
        <label htmlFor="reservationDate" className='mb-3'>Date de réservation</label>
        <input
          type="date"
          className="input input-bordered w-full mb-3"
          id="reservationDate"
          value={selectedDate.split('/').reverse().join('-')}
          onChange={handleDateChange}
          min={formattedToday.split('/').reverse().join('-')}
        />

        <label htmlFor="startTime" className='mb-3'>Heure de début</label>
        <select
          id="startTime"
          className='select select-bordered w-full  mb-3'
          value={selectedStartTime}
          onChange={(e) => setSelectedStartTime(e.target.value)}
          disabled={!selectedDate}
        >
          <option value="">Sélectionnez l'heure de début</option>
          {availableTimes.map((time) => (
            <option key={time} value={time}>
              {time}
            </option>
          ))}
        </select>

        <label htmlFor="endTime" className='mb-3'>Heure de fin</label>
        <select
          id="endTime"
          className='select select-bordered w-full mb-3'
          value={selectedEndTime}
          onChange={(e) => setSelectedEndTime(e.target.value)}
          disabled={!selectedStartTime}
        >
          <option value="">Sélectionnez l'heure de fin</option>
          {availableTimes
            .filter((time) => time > selectedStartTime)
            .map((time) => (
              <option key={time} value={time}>
                {time}
              </option>
            ))}
        </select>

        <div className='flex justify-end mt-2'>
          <button
            className=' btn-secondary  btn '
            type="button"
            onClick={handleSubmit}
          >
            Réserver
          </button>

        </div>
      </form>
    </div>
  );
};

export default RoomReservation;
