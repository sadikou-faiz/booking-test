'use client';

import React, { useEffect, useState } from 'react';
import { useKindeBrowserClient } from "@kinde-oss/kinde-auth-nextjs";
import Image from 'next/image';
import RoomReservation from '../components/makeReservation';
import { Clock, Users } from 'lucide-react';
import Wrapper from '../components/Wrapper';

const Page = () => {
    const { user } = useKindeBrowserClient();
    const [companyId, setCompanyId] = useState<string | null>(null);
    const [rooms, setRooms] = useState<any[]>([]);
    const [companyName, setCompanyName] = useState('');
    const [loading, setLoading] = useState(true); // Ajout de l'état de chargement



    // Supprimer automatiquement les réservations expirées
    const cleanupExpiredReservations = async () => {
        try {
            await fetch('/api/cleanupReservations', {
                method: 'DELETE',
            });
        } catch (error) {
            console.error('Error cleaning up reservations:', error);
        }
    };

    // Récupération de l'ID de l'entreprise de l'utilisateur
    const fetchCompanyId = async () => {
        if (user) {
            try {
                const response = await fetch('/api/users', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        email: user.email,
                        familyName: user.family_name,
                        givenName: user.given_name,
                    }),
                });

                const data = await response.json();
                setCompanyId(data.companyId || null); // Mise à jour avec l'ID ou null
                setLoading(false);
            } catch (error) {
                console.error("Erreur lors de la récupération de l'ID de l'entreprise:", error);
                setCompanyId(null);
            }
        }
    };

    // Récupération des salles pour l'entreprise associée
    const fetchRooms = async () => {
        if (companyId) {
            setLoading(true); // Début du chargement lors de la récupération des salles
            try {
                const response = await fetch(`/api/rooms?companyId=${companyId}`);
                if (!response.ok) {
                    throw new Error('Erreur lors de la récupération des salles.');
                }
                const data = await response.json();
                setRooms(data.rooms);
                setCompanyName(data.companyName);
                setLoading(false);
            } catch (error: any) {
                console.error(error.message);
            }
        }
    };

    useEffect(() => {
        const initializeData = async () => {
            await cleanupExpiredReservations();
            await fetchCompanyId();
        };

        initializeData();
    }, [user]);

    useEffect(() => {
        if (companyId) {
            fetchRooms();
        }
    }, [companyId]);

    // Si l'ID de l'entreprise n'a pas encore été vérifié, afficher un indicateur de chargement
    if (loading) {
        return (
            <Wrapper>
                <div className=" w-full flex justify-center ">
                    <span className="loading loading-spinner loading-lg"></span>
                </div>
            </Wrapper>
        );
    }



    // Rendu principal avec la liste des salles disponibles
    return (
        <Wrapper>
            <div>
                <div>
                    <div className="badge badge-secondary badge-outline mb-2">
                        {!companyName ? "Vous n'êtes pas associé à une entreprise." : companyName}
                    </div>
                    <h1 className="text-2xl mb-4">Réserver une salle</h1>

                    {loading ? (
                        <div className="text-center mt-32">
                            <span className="loading loading-spinner loading-lg"></span>
                        </div>
                    ) : !companyId ? (
                        <div>
                            Vous n'êtes pas associé à une entreprise.
                        </div>
                    ) : rooms.length === 0 ? (
                        <p>Aucune salle pour votre entreprise.</p>
                    ) : (
                        <ul className='grid md:grid-cols-3 gap-4'>
                            {rooms.map((room) => (
                                <li key={room.id} className='flex flex-col border-base-300 border p-5 rounded-2xl'>
                                    <Image
                                        src={`${room?.imageUrl}`}
                                        alt={`${room.id}`}
                                        width={400}
                                        height={400}
                                        quality={90}
                                        className='shadow-sm w-full h-48 object-cover rounded-xl'
                                        loading='lazy'
                                    />
                                    <div className='mt-4'>
                                        <div className='flex items-center'>
                                            <div className="badge badge-secondary">
                                                <Users className="mr-2 w-4" /> {room.capacity}
                                            </div>
                                            <h1 className='font-bold text-xl ml-2'>{room.name}</h1>
                                        </div>
                                        <p className='text-sm my-2 text-gray-500'>
                                            {room.description.length > 100
                                                ? `${room.description.slice(0, 100)}...`
                                                : room.description}
                                        </p>

                                        <button
                                            className="mt-2 btn btn-outline btn-secondary btn-sm"
                                            onClick={() => (document.getElementById(`my_modal_${room.id}`) as HTMLDialogElement).showModal()}
                                        >
                                            <Clock className="w-4" /> Réserver
                                        </button>

                                        <dialog id={`my_modal_${room.id}`} className="modal">
                                            <div className="modal-box relative">
                                                <form method="dialog">
                                                    {/* Close button in the form */}
                                                    <button className="btn btn-sm btn-circle btn-ghost absolute right-2 top-2">✕</button>
                                                </form>

                                                <h3 className="font-bold text-lg mb-2">Réservation</h3>

                                                <div className="flex items-center mb-2">
                                                    <div className="badge badge-secondary">
                                                        <Users className="mr-2 w-4" /> {room.capacity}
                                                    </div>
                                                    <h1 className="font-bold text-xl ml-2">{room.name}</h1>
                                                </div>

                                                <p className="text-sm my-2 text-gray-500">{room.description}</p>

                                                <RoomReservation roomId={room.id} />
                                            </div>
                                        </dialog>
                                    </div>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>
        </Wrapper>
    );

};

export default Page;
