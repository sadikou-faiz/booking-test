"use client";
import Wrapper from '@/app/components/Wrapper';
import React, { useEffect, useState } from 'react';

interface Reservation {
  startTime: string;
  endTime: string;
}

interface RoomData {
  roomName: string;
  existingReservations: Reservation[];
}

function Page({ params }: { params: { roomId: string } }) {
  const today = new Date();
  const formattedToday = `${String(today.getDate()).padStart(2, '0')}/${String(today.getMonth() + 1).padStart(2, '0')}/${today.getFullYear()}`;
  const [roomData, setRoomData] = useState<RoomData | null>(null);
  const [availableTimes, setAvailableTimes] = useState<string[]>([]);
  const [selectedStartTime, setSelectedStartTime] = useState('');
  const [selectedEndTime, setSelectedEndTime] = useState('');
  const [selectedDate, setSelectedDate] = useState(formattedToday);

  const fetchRoomData = async () => {
    const response = await fetch('/api/disponibilities', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        roomId: params.roomId,
        reservationDate: selectedDate,
      }),
    });

    if (!response.ok) {
      console.error("Erreur lors de la récupération des données:", response.statusText);
      return;
    }

    const data: RoomData = await response.json();
    setRoomData(data);

    const allTimeSlots: string[] = [];
    for (let hour = 8; hour < 20; hour++) {
      for (let minute = 0; minute < 60; minute += 15) {
        const time = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
        allTimeSlots.push(time);
      }
    }

    const unavailableTimes = data.existingReservations.flatMap(reservation => {
      const startTime = reservation.startTime;
      const endTime = reservation.endTime;
      return allTimeSlots.filter(time => time >= startTime && time < endTime);
    });

    const available = allTimeSlots.filter(time => !unavailableTimes.includes(time));
    setAvailableTimes(available);
  };

  useEffect(() => {
    if (!selectedDate) return;

    fetchRoomData();
  }, [params.roomId, selectedDate]);

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const chosenDate = e.target.value;
    const [year, month, day] = chosenDate.split('-');
    const formattedDate = `${day}/${month}/${year}`;

    if (chosenDate >= today.toISOString().split('T')[0]) {
      setSelectedDate(formattedDate);
    } else {
      alert("Vous ne pouvez pas sélectionner une date antérieure à aujourd'hui.");
    }
  };

  // Fonction pour soumettre la réservation
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault(); // Empêche le rechargement de la page

    const response = await fetch('/api/reservations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: "faizdeveloppement@gmail.com", // Utilisez l'email approprié ici
        roomId: params.roomId,
        reservationDate: selectedDate,
        startTime: selectedStartTime,
        endTime: selectedEndTime,
      }),
    });

    if (response.ok) {
      const result = await response.json();
      alert(`Réservation réussie ! ID: ${result.id}`); // Alerte de succès
      // Rafraîchir les données des salles si nécessaire
      setSelectedStartTime('');
      setSelectedEndTime('');
      fetchRoomData();
    } else {
      const errorData = await response.json();
      alert(`Erreur lors de la réservation : ${errorData.message || "Une erreur est survenue."}`); // Alerte d'erreur
    }
  };

  return (
    <Wrapper>
    <div>
      <h1>Room: {roomData?.roomName}</h1>

      <form onSubmit={handleSubmit} className='flex flex-col'>
        <label htmlFor="reservationDate">Date de réservation:</label>
        <input
          type="date"
          className="input"
          id="reservationDate"
          value={selectedDate.split('/').reverse().join('-')}
          onChange={handleDateChange}
          min={formattedToday.split('/').reverse().join('-')}
        />

        <label htmlFor="startTime">Heure de début:</label>
        <select
          id="startTime"
          className='select select-bordered w-full max-w-xs'
          value={selectedStartTime}
          onChange={(e) => setSelectedStartTime(e.target.value)}
          disabled={!selectedDate}
        >
          <option value="">Sélectionnez l'heure de début</option>
          {availableTimes.map((time) => (
            <option key={time} value={time}>
              {time}
            </option>
          ))}
        </select>

        <label htmlFor="endTime">Heure de fin:</label>
        <select
          id="endTime"
          className='select select-bordered w-full max-w-xs'
          value={selectedEndTime}
          onChange={(e) => setSelectedEndTime(e.target.value)}
          disabled={!selectedStartTime}
        >
          <option value="">Sélectionnez l'heure de fin</option>
          {availableTimes
            .filter((time) => time > selectedStartTime)
            .map((time) => (
              <option key={time} value={time}>
                {time}
              </option>
            ))}
        </select>

        <button className='btn btn-accent' type="submit">Réserver</button>
      </form>
    </div>
    </Wrapper>
  );
}

export default Page;
