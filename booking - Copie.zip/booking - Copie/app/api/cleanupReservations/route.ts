// pages/api/cleanupReservations.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma'; // Ajuste le chemin si nécessaire
import dayjs from 'dayjs'; // Installe dayjs pour manipuler les dates

export async function DELETE(request: Request) {
  try {
    // Obtenir la date et l'heure actuelles
    const now = dayjs();

    // Récupérer toutes les réservations dont la date ou l'heure sont dépassées
    const expiredReservations = await prisma.reservation.findMany({
      where: {
        OR: [
          {
            reservationDate: {
              lt: now.format('DD/MM/YYYY'), // Date passée
            },
          },
          {
            reservationDate: {
              equals: now.format('DD/MM/YYYY'), // Date actuelle
            },
            endTime: {
              lt: now.format('HH:mm'), // Heure de fin passée
            },
          },
        ],
      },
    });

    // Supprimer les réservations expirées
    if (expiredReservations.length > 0) {
      await prisma.reservation.deleteMany({
        where: {
          id: {
            in: expiredReservations.map((reservation) => reservation.id),
          },
        },
      });
    }

    return NextResponse.json({ message: 'Expired reservations cleaned up' });
  } catch (error) {
    console.error('Error cleaning up reservations:', error);
    return NextResponse.json({ message: 'Internal server error' }, { status: 500 });
  }
}
