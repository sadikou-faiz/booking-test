import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma'; // Ajuster le chemin si nécessaire


//crere une salle et uploder limage

export async function POST(request: Request) {
    try {
        // Extraction des données du body
        const { action, name, capacity, description, imageUrl, companyId, roomId } = await request.json();

        // Validation de l'action
        if (!action || (action !== 'SAVE_DATA' && action !== 'SAVE_IMAGE')) {
            return NextResponse.json({ message: 'Action invalide.' }, { status: 400 });
        }

        // Si l'action est 'SAVE_DATA'
        if (action === 'SAVE_DATA') {
            if (!name || !capacity || !companyId) {
                return NextResponse.json(
                    { message: 'Le nom, la capacité, et l\'ID de l\'entreprise sont requis.' },
                    { status: 400 }
                );
            }

            // Vérifiez si la salle existe déjà pour cette entreprise
            const existingRoom = await prisma.room.findFirst({
                where: {
                    name: name,
                    companyId: companyId,
                },
            });

            if (existingRoom) {
                return NextResponse.json(
                    { message: 'Cette salle existe déjà pour cette entreprise.' },
                    { status: 409 } // Conflit
                );
            }

            // Création de la nouvelle salle dans la base de données
            const newRoom = await prisma.room.create({
                data: {
                    name,
                    capacity: parseInt(capacity, 10),
                    description,
                    company: { connect: { id: companyId } },
                },
            });

            return NextResponse.json({ message: "Salle créée", roomId: newRoom.id }, { status: 201 });

        } else if (action === 'SAVE_IMAGE') {
            if (!roomId || !imageUrl) {
                return NextResponse.json(
                    { message: 'L\'ID de la salle et l\'URL de l\'image sont requis.' },
                    { status: 400 }
                );
            }

            // Mise à jour de la salle avec l'URL de l'image
            const updatedRoom = await prisma.room.update({
                where: { id: roomId },
                data: { imageUrl },
            });

            return NextResponse.json({ message: "Image mise à jour", roomId: updatedRoom.id }, { status: 200 });
        }

    } catch (error) {
        console.error('Erreur lors de la création de la salle ou de la mise à jour de l\'image:', error);
        return NextResponse.json(
            { message: 'Erreur interne du serveur.' },
            { status: 500 }
        );
    }
}


// récupération de toutes les roomm du company id  

export async function GET(request: Request) {
    const { searchParams } = new URL(request.url);
    const companyId = searchParams.get('companyId');

    // Validation de companyId
    if (!companyId) {
        return NextResponse.json(
            { message: 'L\'ID de l\'entreprise est requis.' },
            { status: 400 }
        );
    }

    try {
        // Récupérer toutes les salles associées à l'ID de l'entreprise
        const rooms = await prisma.room.findMany({
            where: {
                companyId: companyId,
            },
        });

        const company = await prisma.company.findUnique({
            where: {
                id: companyId,
            },
        });


        return NextResponse.json({ rooms, companyName: company?.name }, { status: 200 });

    } catch (error) {
        console.error('Erreur lors de la récupération des salles:', error);
        return NextResponse.json(
            { message: 'Erreur interne du serveur lors de la récupération des salles.' },
            { status: 500 }
        );
    }
}


//suprimer une rroom 

export async function DELETE(request: Request) {
    const { roomId } = await request.json(); // Récupérer l'ID de la salle du corps de la requête

    if (!roomId) {
        return NextResponse.json(
            { message: 'L\'ID de la salle est requis' },
            { status: 400 }
        );
    }

    try {
        // Supprimer d'abord toutes les réservations associées à cette salle
        await prisma.reservation.deleteMany({
            where: {
                roomId: roomId,
            },
        });

        // Ensuite, supprimez la salle elle-même
        await prisma.room.delete({
            where: { id: roomId },
        });

        return NextResponse.json(
            { message: 'Salle et réservations supprimées avec succès' },
            { status: 200 }
        );
    } catch (error) {
        console.error('Erreur lors de la suppression de la salle :', error);
        return NextResponse.json(
            { message: 'Erreur lors de la suppression de la salle' },
            { status: 500 }
        );
    }
}
