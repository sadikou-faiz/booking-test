// src/app/api/get-employees/route.ts
import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma'; // Ajuste le chemin si nécessaire

export async function GET(request: Request) {
    try {
        const { searchParams } = new URL(request.url);
        const companyId = searchParams.get('companyId'); // Récupérer l'ID de l'entreprise

        // Vérifier que l'ID de l'entreprise est fourni
        if (!companyId) {
            return NextResponse.json(
                { message: 'L\'ID de l\'entreprise est requis.' },
                { status: 400 }
            );
        }


        // Récupérer les employés de l'entreprise
        const employees = await prisma.user.findMany({
            where: {
                companyId, // Filtrer par ID de l'entreprise
            },
            select: {
                id: true,
                email: true,
                givenName: true,
                familyName: true,
            },
        });

        //recuperre le nom de l'entreprise
        const company = await prisma.company.findUnique({
            where: {
                id: companyId,
            },
            select: {
                name: true, // Récupérer seulement le nom
            },
        });

        // Vérifier si l'entreprise existe
        if (!company) {
            return NextResponse.json(
                { message: 'Entreprise non trouvée.' },
                { status: 404 }
            );
        }


        // Formater la réponse pour inclure des valeurs nulles pour les champs manquants
        const formattedEmployees = employees.map((employee) => ({
            id: employee.id,
            email: employee.email,
            givenName: employee.givenName || null, // Renvoie null si absent
            familyName: employee.familyName || null, // Renvoie null si absent
        }));

        return NextResponse.json(
            {
                employees: formattedEmployees,
                companyName: company.name
            },
            { status: 200 }
        );

    } catch (error) {
        console.error('Erreur lors de la récupération des employés:', error);
        return NextResponse.json(
            { message: 'Erreur interne du serveur lors de la récupération des employés.' },
            { status: 500 }
        );
    }
}
