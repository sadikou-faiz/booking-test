import { initEdgeStore } from '@edgestore/server';
import { createEdgeStoreNextHandler } from '@edgestore/server/adapters/next/app';

const es = initEdgeStore.create();

/**
 * Ceci est le routeur principal pour les buckets Edge Store.
 * Nous créons un bucket de fichiers simple nommé `publicFiles`.
 */
const edgeStoreRouter = es.router({
  publicFiles: es
    .fileBucket()
    /**
     * Retourner `true` pour autoriser l'upload
     * Par défaut, chaque upload depuis votre application est autorisé.
     */
    .beforeUpload(({ ctx, input, fileInfo }) => {
      console.log('beforeUpload', ctx, input, fileInfo);
      return true; // autoriser l'upload
    })
    /**
     * Retourner `true` pour autoriser la suppression
     * Cette fonction doit être définie si vous voulez supprimer des fichiers directement depuis le client.
     */
    .beforeDelete(({ ctx, fileInfo }) => {
      console.log('beforeDelete', ctx, fileInfo);
      return true; // autoriser la suppression
    }),
});

const handler = createEdgeStoreNextHandler({
  router: edgeStoreRouter,
});

export { handler as GET, handler as POST };

/**
 * Ce type est utilisé pour créer le client typé en toute sécurité pour le frontend.
 */
export type EdgeStoreRouter = typeof edgeStoreRouter;
