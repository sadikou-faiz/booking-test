// app/api/reservations/route.ts

import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma'; // Ajustez le chemin si nécessaire

export async function POST(request: Request) {
    try {
        // Extraction des données du corps de la requête
        const { email, roomId, reservationDate, startTime, endTime } = await request.json();

        // Vérification des champs requis
        if (!email || !roomId || !reservationDate || !startTime || !endTime) {
            return NextResponse.json({ error: 'Tous les champs sont requis.' }, { status: 400 });
        }

        // Recherche de l'utilisateur par email
        const user = await prisma.user.findUnique({
            where: { email: email },
        });

        // Vérification si l'utilisateur existe
        if (!user) {
            return NextResponse.json({ error: 'Utilisateur non trouvé.' }, { status: 404 });
        }

        // Création de la réservation
        const reservation = await prisma.reservation.create({
            data: {
                userId: user.id, // Utilisation de l'ID de l'utilisateur trouvé
                roomId,
                reservationDate,
                startTime,
                endTime,
            },
        });

        // Renvoie la réservation créée
        return NextResponse.json(reservation, { status: 201 });
    } catch (error) {
        console.error("Erreur lors de la création de la réservation:", error);

        return NextResponse.json({ error: 'Erreur lors de la création de la réservation.' }, { status: 500 });
    }
}


// Liste de toutes les réservations
export async function GET(request: Request) {
    try {
      const { searchParams } = new URL(request.url);
      const email = searchParams.get('email'); // Récupérer l'email
  
      if (!email) {
        return NextResponse.json({ message: 'L\'email est requis' }, { status: 400 });
      }
  
      // Récupérer l'utilisateur par email
      const user = await prisma.user.findUnique({
        where: { email },
        include: {
          reservations: {
            include: {
              room: true, // Inclure les détails de la salle
            },
          },
        },
      });
  
      if (!user) {
        return NextResponse.json({ message: 'Utilisateur non trouvé' }, { status: 404 });
      }

              // Retourner les réservations de l'utilisateur sans le champ userId
              const reservationsWithoutUserId = user.reservations.map(({ userId, ...rest }) => rest);

  
      // Retourner les réservations de l'utilisateur
      return NextResponse.json(reservationsWithoutUserId);
    } catch (error) {
      console.error('Erreur lors de la récupération des réservations :', error);
      return NextResponse.json({ message: 'Erreur interne du serveur' }, { status: 500 });
    }
  }

  //SUPRIMER UNE RESERVATION
  export async function DELETE(request: Request) {
    try {
        const { id } = await request.json(); // Récupérer l'ID de la réservation depuis le corps de la requête

        if (!id) {
            return NextResponse.json({ message: 'Reservation ID is required' }, { status: 400 });
        }

        // Supprimer la réservation par ID
        const deletedReservation = await prisma.reservation.delete({
            where: { id },
        });

        // Retourner la réservation supprimée ou un message de succès
        return NextResponse.json({ message: 'Reservation deleted successfully', deletedReservation });
    } catch (error) {
        console.error('Error deleting reservation:', error);
        return NextResponse.json({ message: 'Internal server error' }, { status: 500 });
    }
}
  