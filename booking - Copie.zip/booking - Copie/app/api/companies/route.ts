import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma'; // Ajustez le chemin si nécessaire


//creation d'une entreprise

export async function POST(request: Request) {
    try {
        // Extraction des données du corps de la requête
        const { email, companyName } = await request.json();

        // Vérifier si les champs obligatoires sont présents
        if (!email || !companyName) {
            return NextResponse.json(
                { message: 'Email et nom de l\'entreprise sont requis.' },
                { status: 400 }
            );
        }

        // Vérifier si l'utilisateur existe avec cet email
        const user = await prisma.user.findUnique({
            where: { email },
        });

        if (!user) {
            return NextResponse.json(
                { message: 'Utilisateur non trouvé.' },
                { status: 404 }
            );
        }

        // Vérifier si une entreprise avec ce nom existe déjà
        const existingCompany = await prisma.company.findUnique({
            where: { name: companyName },
        });

        if (existingCompany) {
            return NextResponse.json(
                { message: 'Une entreprise avec ce nom existe déjà.' },
                { status: 409 }
            );
        }

        // Créer une nouvelle entreprise et associer l'utilisateur comme créateur et employé
        const newCompany = await prisma.company.create({
            data: {
                name: companyName,
                createdBy: { connect: { id: user.id } }, // Associer l'utilisateur comme créateur
                employees: { connect: { id: user.id } }, // Ajouter l'utilisateur comme employé
            },
        });

        return NextResponse.json(
            { message: 'Entreprise créée avec succès.', company: newCompany },
            { status: 201 }
        );
    } catch (error) {
        console.error('Erreur lors de la création de l\'entreprise:', error);
        return NextResponse.json(
            { message: 'Erreur interne du serveur lors de la création de l\'entreprise.' },
            { status: 500 }
        );
    }
}

//listes des entreprises créer

export async function GET(request: Request) {
    try {
        // Récupérer l'email de l'utilisateur depuis les paramètres de la requête
        const { searchParams } = new URL(request.url);
        const email = searchParams.get('email');

        // Vérifier que l'email est fourni
        if (!email) {
            return NextResponse.json(
                { message: 'L\'email est requis.' },
                { status: 400 }
            );
        }

        // Vérifier si l'utilisateur existe avec cet email
        const user = await prisma.user.findUnique({
            where: { email },
        });

        if (!user) {
            return NextResponse.json(
                { message: 'Utilisateur non trouvé.' },
                { status: 404 }
            );
        }

        // Récupérer les entreprises créées par l'utilisateur
        const companies = await prisma.company.findMany({
            where: {
                createdById: user.id, // Filtrer uniquement les entreprises créées par l'utilisateur
            },
        });

        return NextResponse.json(
            { companies },
            { status: 200 }
        );
    } catch (error) {
        console.error('Erreur lors de la récupération des entreprises:', error);
        return NextResponse.json(
            { message: 'Erreur interne du serveur lors de la récupération des entreprises.' },
            { status: 500 }
        );
    }
}

//ajouter des employé 

export async function PATCH(request: Request) {
    try {
        // Extraction des données du corps de la requête
        const { id, creatorEmail, employeeEmail, action } = await request.json();

        // Vérification de l'existence du créateur
        const creator = await prisma.user.findUnique({
            where: { email: creatorEmail },
        });

        // Si le créateur n'existe pas, renvoyez une réponse d'erreur
        if (!creator) {
            return NextResponse.json({ error: 'Créateur non trouvé' }, { status: 404 });
        }

        // Vérification de l'existence de l'entreprise
        const company = await prisma.company.findUnique({
            where: { id },
        });

        // Si l'entreprise n'existe pas, renvoyez une réponse d'erreur
        if (!company) {
            return NextResponse.json({ error: 'Entreprise non trouvée' }, { status: 404 });
        }

        // Vérifiez si l'utilisateur qui a créé l'entreprise correspond à l'email du créateur
        if (company.createdById !== creator.id) {
            return NextResponse.json({ error: 'L\'utilisateur n\'est pas le créateur de l\'entreprise' }, { status: 403 });
        }

        if (action === 'ADD') {
            // Vérifier si l'employé existe déjà
            let employee = await prisma.user.findUnique({
                where: { email: employeeEmail },
            });

            // Si l'employé existe, vérifier s'il est déjà associé à l'entreprise actuelle
            if (employee?.companyId === company.id) {
                return NextResponse.json({
                    error: `${employeeEmail} est déjà dans l'entreprise.`,
                }, { status: 400 });
            }

            // Si l'employé existe mais est associé à une autre entreprise
            if (employee?.companyId && employee.companyId !== company.id) {
                return NextResponse.json({
                    error: `Cet employé appartient déjà à une autre entreprise.`,
                }, { status: 400 });
            }

            // Si l'employé n'existe pas, le créer
            if (!employee) {
                employee = await prisma.user.create({
                    data: {
                        email: employeeEmail,
                        companyId: company.id, // Lien vers l'entreprise
                    },
                });
            } else {
                // Sinon, ajouter l'entreprise à l'employé
                await prisma.user.update({
                    where: { id: employee.id },
                    data: {
                        companyId: company.id, // Lien vers l'entreprise
                    },
                });
            }

            // Ajout de l'employé à l'entreprise
            await prisma.company.update({
                where: { id: company.id },
                data: {
                    employees: {
                        connect: { id: employee.id },
                    },
                },
            });

            return NextResponse.json({
                message: 'Employé ajouté avec succès',
                employee, // Inclure les détails de l'employé
            }, { status: 201 });
        }
        else if (action === 'DELETE') {
            // Vérifier si l'employé existe
            const employee = await prisma.user.findUnique({
                where: { email: employeeEmail },
            });

            // Si l'employé n'existe pas, renvoyez une réponse d'erreur
            if (!employee) {
                return NextResponse.json({ error: 'Employé non trouvé' }, { status: 404 });
            }

            // Suppression de l'employé de l'entreprise
            await prisma.company.update({
                where: { id: company.id },
                data: {
                    employees: {
                        disconnect: { id: employee.id },
                    },
                },
            });

            return NextResponse.json({
                message: 'Employé supprimé avec succès',
            }, { status: 200 });

        } else {
            return NextResponse.json({ error: 'Action non valide' }, { status: 400 });
        }

    } catch (error) {
        console.error(error);
        return NextResponse.json({ error: 'Erreur lors de l\'ajout ou de la suppression de l\'employé' }, { status: 500 });
    }
}



// suprimer une entreprise 

export async function DELETE(request: Request) {
    try {
        // Extraire l'ID de l'entreprise du corps de la requête
        const { id } = await request.json();

        // Vérification de l'existence de l'entreprise
        const company = await prisma.company.findUnique({
            where: { id },
        });

        // Si l'entreprise n'existe pas, renvoyer une réponse d'erreur
        if (!company) {
            return NextResponse.json({ error: 'Entreprise non trouvée' }, { status: 404 });
        }

        // Supprimer les réservations associées aux salles de l'entreprise
        await prisma.reservation.deleteMany({
            where: {
                room: {
                    companyId: id,
                },
            },
        });

        // Supprimer les salles associées à l'entreprise
        await prisma.room.deleteMany({
            where: {
                companyId: id,
            },
        });

        // Déconnecter tous les utilisateurs associés à cette entreprise
        await prisma.user.updateMany({
            where: { companyId: id },
            data: { companyId: null }, // Retirer l'association de l'utilisateur à l'entreprise
        });

        // Supprimer l'entreprise
        await prisma.company.delete({
            where: { id },
        });

        return NextResponse.json({
            message: 'Entreprise, salles, et réservations supprimées avec succès',
        }, { status: 200 });

    } catch (error) {
        console.error('Erreur lors de la suppression de l\'entreprise:', error);
        return NextResponse.json({ error: 'Erreur interne du serveur' }, { status: 500 });
    }
}
