import { NextResponse } from 'next/server';
import prisma from '@/lib/prisma'; // Ajuste le chemin si nécessaire

export async function POST(request: Request) {
    try {
        const { roomId, reservationDate } = await request.json();

        // Validation de l'entrée
        if (!roomId || !reservationDate) {
            return NextResponse.json(
                { message: 'roomId et reservationDate sont requis.' },
                { status: 400 }
            );
        }

        // Validation du format de la date (dd/MM/yyyy)
        const dateParts = reservationDate.split('/');
        if (dateParts.length !== 3 || dateParts[2].length !== 4) {
            return NextResponse.json(
                { message: 'Format de date invalide. Utilisez le format dd/MM/yyyy.' },
                { status: 400 }
            );
        }

        const date = new Date(`${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`); // Conversion en objet Date

        // Vérifier si la date est valide
        if (isNaN(date.getTime())) {
            return NextResponse.json(
                { message: 'Date invalide.' },
                { status: 400 }
            );
        }

        // Vérifier si la salle existe
        const room = await prisma.room.findUnique({
            where: { id: roomId },
            select: { name: true },
        });

        if (!room) {
            return NextResponse.json(
                { message: 'Salle non trouvée.' },
                { status: 404 }
            );
        }

        // Récupérer toutes les réservations pour cette salle à la date donnée
        const existingReservations = await prisma.reservation.findMany({
            where: {
                roomId: roomId,
                reservationDate: reservationDate, // Comparer la chaîne de date au lieu de l'objet Date
            },
            select: {
                startTime: true,
                endTime: true,
            },
        });


        return NextResponse.json({ roomName: room.name, existingReservations }, { status: 200 });
    } catch (error) {
        console.error('Erreur lors de la récupération des heures réservées:', error);
        return NextResponse.json(
            { message: 'Erreur interne du serveur.' },
            { status: 500 }
        );
    }
}
