/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
        domains: ['files.edgestore.dev'], // Ajoutez le domaine ici
      },
};

export default nextConfig;
